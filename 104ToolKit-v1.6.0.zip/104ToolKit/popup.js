const byId = (id) => document.getElementById(id);

const ui = {
  globalStatus: byId("globalStatus"),
  startWorkflow: byId("startWorkflow"),
  stopWorkflow: byId("stopWorkflow"),
  workflowPhase: byId("workflowPhase"),
  workflowProgress: byId("workflowProgress"),
  workflowBar: byId("workflowBar"),
  workflowMessage: byId("workflowMessage"),
  settingsStatus: byId("settingsStatus"),
  toggleCopyPanel: byId("toggleCopyPanel"),
  toggleExportPanel: byId("toggleExportPanel"),
  copyPanel: byId("copyPanel"),
  exportPanel: byId("exportPanel"),
  copyCurrent: byId("copyCurrent"),
  copyRight: byId("copyRight"),
  stopCopy: byId("stopCopy"),
  copyCount: byId("copyCount"),
  copyStatus: byId("copyStatus"),
  downloadCurrent: byId("downloadCurrent"),
  downloadRight: byId("downloadRight"),
  stopPdf: byId("stopPdf"),
  pdfProgress: byId("pdfProgress"),
  pdfStatus: byId("pdfStatus")
};

let legacySubdir = "";
let groupInfo = { hasGroup: false, title: "" };
let workflowRunning = false;
let jobsRunning = false;
let classificationBusy = false;
let canClassify = false;
let hasTrainingLabel = false;
let currentTrainingLabel = "";
let canGroupJob = false;
let currentResumeKey = "";
let reasonWrite = Promise.resolve();
let reasonVersion = 0;
let settingsVersion = 0;

function updateClassificationAvailability() {
  document.querySelectorAll(".classification-button").forEach(button => {
    button.disabled = classificationBusy || !canClassify;
  });
  byId("trainingReason").disabled = classificationBusy || !canClassify;
  byId("removeTrainingLabel").disabled = classificationBusy || !canClassify || !hasTrainingLabel;
  [ui.startWorkflow, ui.copyCurrent, ui.copyRight, ui.downloadCurrent, ui.downloadRight].forEach(button => {
    button.disabled = jobsRunning || classificationBusy;
  });
  byId("jobGroupSelect").disabled = classificationBusy || jobsRunning || !canGroupJob;
  byId("addJobGroup").disabled = classificationBusy || jobsRunning || !canGroupJob || !byId("jobGroupSelect").value;
}

function selectMode(mode) {
  const tag = mode === "tag";
  byId("tagTab").setAttribute("aria-selected", String(tag));
  byId("dataTab").setAttribute("aria-selected", String(!tag));
  byId("tagTab").tabIndex = tag ? 0 : -1;
  byId("dataTab").tabIndex = tag ? -1 : 0;
  byId("tagWorkflow").hidden = !tag;
  byId("dataWorkflow").hidden = tag;
}

async function refreshClassification() {
  const result = await sendClassification({ type: "TOOLKIT_GET_CLASSIFIER_STATE" });
  if (!result?.ok) throw new Error(result?.error || "無法讀取分類。");
  canClassify = result.canClassify;
  currentResumeKey = result.resumeKey || "";
  byId("trainingReason").value = result.reason || "";
  currentTrainingLabel = result.trainingLabel || "";
  hasTrainingLabel = Boolean(currentTrainingLabel);
  canGroupJob = result.canGroupJob;
  byId("jobCurrentGroup").textContent = result.groupTitle || "尚未分類";
  const select = byId("jobGroupSelect");
  if (select.options.length === 1) {
    (result.jobGroups || []).forEach(title => {
      const option = document.createElement("option");
      option.value = title;
      option.textContent = title;
      select.append(option);
    });
    const { lastJobGroup = "" } = await chrome.storage.local.get("lastJobGroup");
    const preferred = result.jobGroups?.includes(result.groupTitle) ? result.groupTitle : lastJobGroup;
    if (result.jobGroups?.includes(preferred)) select.value = preferred;
  }
  if (!canGroupJob) byId("jobGroupStatus").textContent = "請先切換到要加入職缺群組的網頁。";
  byId("classificationGroup").textContent = result.trainingLabel || "尚未標記";
  groupInfo = { hasGroup: Boolean(result.groupTitle), title: result.groupTitle || "" };
  const actions = byId("classificationActions");
  actions.querySelectorAll("button").forEach(button => {
    button.setAttribute("aria-pressed", String(button.textContent === result.trainingLabel));
  });
  if (!canClassify) byId("classificationStatus").textContent = "請先切換到 104 VIP 履歷頁再下標籤。";
  updateClassificationAvailability();
  buildPreviewFilename();
}

async function classifyCurrent(categoryId) {
  await reasonWrite;
  classificationBusy = true;
  updateClassificationAvailability();
  byId("classificationStatus").textContent = "正在保存此履歷的訓練分類…";
  try {
    const result = await sendClassification({ type: "CLASSIFY_CURRENT_TAB", categoryId });
    if (!result?.ok) throw new Error(result?.error || "分類失敗。");
    await refreshClassification();
    byId("classificationStatus").textContent = `已保存「${result.trainingLabel}」；職缺群組保持原設定。`;
  } catch (error) {
    byId("classificationStatus").textContent = `分類失敗：${errorText(error)}`;
  } finally {
    classificationBusy = false;
    updateClassificationAvailability();
  }
}

async function removeCurrentTrainingLabel() {
  if (classificationBusy || !canClassify || !hasTrainingLabel) return;
  await reasonWrite;
  classificationBusy = true;
  updateClassificationAvailability();
  byId("classificationStatus").textContent = "正在移除此履歷的訓練標籤…";
  try {
    const result = await sendClassification({ type: "TOOLKIT_REMOVE_TRAINING_LABEL" });
    if (!result?.ok) throw new Error(result?.error || "移除標籤失敗。");
    await refreshClassification();
    byId("reasonStatus").textContent = "標籤與原因已移除";
    byId("classificationStatus").textContent = "已移除標籤；此履歷恢復為尚未標記，職缺群組保持原設定。";
  } catch (error) {
    byId("classificationStatus").textContent = `移除失敗：${errorText(error)}`;
  } finally {
    classificationBusy = false;
    updateClassificationAvailability();
  }
}

async function addCurrentToJobGroup() {
  await reasonWrite;
  const groupTitle = byId("jobGroupSelect").value;
  if (!groupTitle || classificationBusy || jobsRunning) return;
  classificationBusy = true;
  updateClassificationAvailability();
  byId("jobGroupStatus").textContent = `正在加入「${groupTitle}」…`;
  try {
    const result = await sendClassification({ type: "TOOLKIT_GROUP_JOB_TAB", groupTitle });
    if (!result?.ok) throw new Error(result?.error || "加入群組失敗。");
    await refreshClassification();
    byId("jobGroupStatus").textContent = `已${result.created ? "建立並加入" : "加入"}「${result.groupTitle}」群組。`;
    byId("classificationStatus").textContent = "職缺群組已更新；此履歷的訓練分類保持原設定。";
    try { await chrome.storage.local.set({ lastJobGroup: groupTitle }); }
    catch (_) { /* 記住選項失敗不影響已完成的分組。 */ }
  } catch (error) {
    byId("jobGroupStatus").textContent = `加入失敗：${errorText(error)}`;
  } finally {
    classificationBusy = false;
    updateClassificationAvailability();
  }
}

// 每次請求使用獨立分類連線，並明確處理未載入、斷線與逾時。
function sendClassification(message) {
  return new Promise((resolve, reject) => {
    const port = chrome.runtime.connect({ name: "toolkit-classifier" });
    let settled = false;
    const timer = setTimeout(() => finish(new Error("分類服務回覆逾時，請重新載入擴充功能後再試。")), 8000);
    function finish(error, result) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      port.disconnect();
      if (error) reject(error); else resolve(result);
    }
    port.onMessage.addListener(result => finish(null, result));
    port.onDisconnect.addListener(() => {
      const detail = chrome.runtime.lastError?.message;
      finish(new Error(detail ? `分類服務連線失敗：${detail}。請重新載入擴充功能。` : "分類服務未連線，請在 chrome://extensions 重新載入 104 招募工作台。"));
    });
    try { port.postMessage(message); } catch (error) { finish(error); }
  });
}

async function send(message) {
  return chrome.runtime.sendMessage(message);
}

function errorText(error) {
  return String(error?.message || error || "未知錯誤");
}

function setGlobalStatus(text, kind = "idle") {
  ui.globalStatus.textContent = text;
  ui.globalStatus.className = `status-badge status-${kind}`;
}

function setExpandedPanel(panelId = null) {
  [
    { button: ui.toggleCopyPanel, panel: ui.copyPanel },
    { button: ui.toggleExportPanel, panel: ui.exportPanel }
  ].forEach(({ button, panel }) => {
    const expanded = panel.id === panelId;
    button.classList.toggle("is-expanded", expanded);
    button.setAttribute("aria-expanded", String(expanded));
    button.querySelector(".toggle-icon").textContent = expanded ? "−" : "＋";
    panel.hidden = !expanded;
  });
}

function togglePanel(panelId) {
  const target = byId(panelId);
  setExpandedPanel(target.hidden ? panelId : null);
}

function renderWorkflow(state = {}) {
  const running = Boolean(state.running);
  workflowRunning = running;
  const current = Number(state.current || 0);
  const total = Number(state.total || 2);
  const percent = total ? Math.min(100, Math.round((current / total) * 100)) : 0;
  const phaseNames = {
    idle: "尚未開始",
    collecting: "正在複製資料",
    exporting: "正在匯出 PDF",
    done: "已完成",
    stopped: "已停止",
    error: "需要處理"
  };

  ui.workflowPhase.textContent = phaseNames[state.phase] || "處理中";
  ui.workflowProgress.textContent = `${current} / ${total}`;
  ui.workflowBar.style.width = `${percent}%`;
  ui.workflowMessage.textContent = state.error
    ? `${state.lastMessage || "工作流失敗"} ${state.error}`
    : (state.lastMessage || "從目前分頁開始，向右處理連續的 104 履歷分頁。");
  ui.startWorkflow.disabled = running || jobsRunning || classificationBusy;
  ui.startWorkflow.classList.toggle("is-hidden", running);
  ui.stopWorkflow.classList.toggle("is-hidden", !running);

}

function renderCopy(state = {}) {
  const running = Boolean(state.running);
  ui.copyCurrent.disabled = running || workflowRunning || jobsRunning || classificationBusy;
  ui.copyRight.disabled = running || workflowRunning || jobsRunning || classificationBusy;
  ui.stopCopy.disabled = !running || workflowRunning || classificationBusy;
  ui.copyCount.textContent = `${state.count || 0} 筆`;
  const statusText = normalizeCopyStatus(state.lastStatusText);
  ui.copyStatus.textContent = running
    ? `收集中｜${state.current || 0}/${state.total || 0}\n${state.lastStatusText || ""}`
    : (statusText || "待命中");
}

function renderPdf(state = {}) {
  const running = Boolean(state.running);
  ui.downloadCurrent.disabled = running || workflowRunning || jobsRunning || classificationBusy;
  ui.downloadRight.disabled = running || workflowRunning || jobsRunning || classificationBusy;
  ui.stopPdf.disabled = !running || workflowRunning || classificationBusy;
  ui.pdfProgress.textContent = state.progressText || "0 / 0";
  ui.pdfStatus.textContent = state.lastMessage || "待命中";
}

async function copyTextToClipboard(text) {
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch (error) {
    console.info("[104 招募工作台] Popup 剪貼簿備援未執行", {
      reason: errorText(error)
    });
  }
}

function normalizeCopyStatus(text) {
  const value = String(text || "");
  if (!/Document is not focused|writeText.*Clipboard/i.test(value)) return value;
  const operation = value.includes("本頁")
    ? "本頁資料已整理完成"
    : "資料已整理完成";
  return `狀態：${operation}，可直接貼上使用`;
}

async function refreshStates() {
  try {
    const [workflow, copy, pdf] = await Promise.all([
      send({ type: "TOOLKIT_GET_WORKFLOW_STATE" }),
      send({ type: "GET_STATE" }),
      send({ cmd: "getStatus" })
    ]);
    const workflowState = workflow?.state || {};
    const copyState = copy?.state || {};
    const pdfState = pdf || {};
    jobsRunning = Boolean(workflowState.running || copyState.running || pdfState.running);
    updateClassificationAvailability();
    if (workflow?.ok) renderWorkflow(workflowState);
    if (copy?.ok) renderCopy(copyState);
    if (pdf) renderPdf(pdfState);

    if (workflowState.running) setGlobalStatus("工作流執行中", "running");
    else if (copyState.running) setGlobalStatus("正在複製", "running");
    else if (pdfState.running) setGlobalStatus("正在匯出", "running");
    else if (workflowState.phase === "done") setGlobalStatus("已完成", "success");
    else if (workflowState.phase === "error") setGlobalStatus("需要處理", "error");
    else setGlobalStatus("待命", "idle");
  } catch (error) {
    setGlobalStatus("無法讀取狀態", "error");
  }
}

function buildPreviewFilename() {
  const mode = byId("prefixMode").value;
  const manualPrefix = byId("filenamePrefix").value.trim();
  const suffix = byId("filenameSuffix").value.trim();
  const prefix = groupInfo.title || (mode === "none" ? "" : manualPrefix);
  byId("trainingFilenamePreview").hidden = !currentTrainingLabel;
  byId("trainingFilenamePreview").textContent = currentTrainingLabel ? ResumeTrainingLabels.trainingFilename("王小明", { label: currentTrainingLabel, reason: byId("trainingReason").value }) : "";
  byId("filenamePreview").textContent = [prefix, "王小明", suffix].filter(Boolean).join("_") + ".pdf";
  byId("groupHint").textContent = groupInfo.hasGroup
    ? `目前群組：${groupInfo.title}`
    : "目前分頁沒有群組；群組模式將改用手動前綴。";
}

async function loadSettings() {
  const { settings = {} } = await chrome.storage.local.get("settings");
  legacySubdir = settings.subdir ?? "104履歷下載區/";
  const output = await RecruitingOutputDirectory.status();
  byId("outputLocation").textContent = output.selected ? output.name : (legacySubdir ? `瀏覽器下載位置／${legacySubdir}` : output.name);
  byId("prefixMode").value = settings.filenamePrefixMode ?? "manual";
  byId("filenamePrefix").value = settings.filenamePrefix ?? "";
  byId("filenameSuffix").value = settings.filenameSuffix ?? "";
  byId("firstWait").value = settings.firstWait ?? 4000;
  byId("nextWait").value = settings.nextWait ?? 800;
  const result = await send({ cmd: "getCurrentTabGroupInfo" });
  groupInfo = result?.ok ? result : groupInfo;
  buildPreviewFilename();
}

async function saveSettings() {
  const version = ++settingsVersion;
  ui.settingsStatus.textContent = "儲存中…";
  const settings = {
    subdir: legacySubdir,
    filenamePrefixMode: byId("prefixMode").value,
    filenamePrefix: byId("filenamePrefix").value.trim(),
    filenameSuffix: byId("filenameSuffix").value.trim(),
    firstWait: Math.max(0, Number(byId("firstWait").value || 0)),
    nextWait: Math.max(0, Number(byId("nextWait").value || 0))
  };
  await chrome.storage.local.set({ settings });
  await send({ cmd: "applySettings" });
  if (version !== settingsVersion) return;
  ui.settingsStatus.textContent = "已自動儲存";
  ui.settingsStatus.classList.add("status-success");
}

function markSettingsDirty() {
  saveSettings().catch(error => {
    ui.settingsStatus.textContent = `儲存失敗：${errorText(error)}，請重新調整後重試。`;
    ui.settingsStatus.classList.remove("status-success");
  });
}
function saveCurrentReason() {
  const version = ++reasonVersion;
  const reason = byId("trainingReason").value;
  byId("reasonStatus").textContent = "儲存中…";
  buildPreviewFilename();
  // 每次輸入即送至背景保存，不以計時器延後，避免關閉 popup 遺失尚未送出的內容。
  reasonWrite = sendClassification({ type: "TOOLKIT_SAVE_TRAINING_REASON", resumeKey: currentResumeKey, reason }).then(result => {
    if (!result?.ok) throw new Error(result?.error || "原因儲存失敗。");
    if (version === reasonVersion) byId("reasonStatus").textContent = reason.trim() ? "原因已自動儲存" : "原因已清空";
  }).catch(error => {
    if (version === reasonVersion) byId("reasonStatus").textContent = `儲存失敗：${errorText(error)}`;
  });
}

async function startCopy(type) {
  const response = await send({ type });
  if (!response?.ok) ui.copyStatus.textContent = `啟動失敗：${response?.error || "未知錯誤"}`;
  await refreshStates();
}

async function launchExport(action) {
  const output = await RecruitingOutputDirectory.status();
  if (output.selected) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const baseUrl = chrome.runtime.getURL("directory.html");
    const url = baseUrl + `?returnTab=${tab?.id || ""}&action=${action}`;
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const toolTab = tabs.find(item => item.url?.startsWith(baseUrl));
    // 放在最左側，避免工具頁插入「本頁往右」的連續履歷範圍。
    if (toolTab) {
      await chrome.tabs.move(toolTab.id, { index: 0 });
      await chrome.tabs.update(toolTab.id, { url, active: true });
    } else await chrome.tabs.create({ url, index: 0 });
    return { ok: true };
  }
  return send(action === "combined" ? { type: "TOOLKIT_START_COMBINED_RIGHT" } : { cmd: action });
}

async function startPdf(cmd) {
  await reasonWrite;
  await saveSettings();
  const response = await launchExport(cmd);
  if (!response?.ok) ui.pdfStatus.textContent = `啟動失敗：${response?.error || "未知錯誤"}`;
  await refreshStates();
}

function bindActions() {
  byId("chooseOutputDirectory").addEventListener("click", async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      await chrome.tabs.create({ url: chrome.runtime.getURL("directory.html") + `?returnTab=${tab?.id || ""}` });
    } catch (error) { byId("outputLocation").textContent = `無法開啟資料夾設定：${errorText(error)}`; }
  });
  byId("removeTrainingLabel").addEventListener("click", removeCurrentTrainingLabel);
  byId("jobGroupSelect").addEventListener("change", updateClassificationAvailability);
  byId("addJobGroup").addEventListener("click", addCurrentToJobGroup);
  document.querySelectorAll(".classification-button").forEach(button => {
    button.addEventListener("click", () => classifyCurrent(button.dataset.category));
  });
  byId("tagTab").addEventListener("click", () => selectMode("tag"));
  byId("dataTab").addEventListener("click", () => selectMode("data"));
  ["tagTab", "dataTab"].forEach((id) => {
    byId(id).addEventListener("keydown", (event) => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      const next = event.key === "Home" ? "tag" : event.key === "End" ? "data" : id === "tagTab" ? "data" : "tag";
      selectMode(next);
      byId(next === "tag" ? "tagTab" : "dataTab").focus();
    });
  });
  ui.toggleCopyPanel.addEventListener("click", () => togglePanel("copyPanel"));
  ui.toggleExportPanel.addEventListener("click", () => togglePanel("exportPanel"));
  ui.startWorkflow.addEventListener("click", async () => {
    await reasonWrite;
    await saveSettings();
    const response = await launchExport("combined");
    if (!response?.ok) {
      renderWorkflow({ phase: "error", error: response?.error || "無法啟動工作流。", total: 2 });
    }
    await refreshStates();
  });
  ui.stopWorkflow.addEventListener("click", () => send({ type: "TOOLKIT_STOP_WORKFLOW" }));
  ui.copyCurrent.addEventListener("click", () => startCopy("START_COPY_CURRENT"));
  ui.copyRight.addEventListener("click", () => startCopy("START_COLLECT_RIGHT"));
  ui.stopCopy.addEventListener("click", () => send({ type: "PAUSE_COLLECT" }));
  ui.downloadCurrent.addEventListener("click", () => startPdf("downloadCurrent"));
  ui.downloadRight.addEventListener("click", () => startPdf("downloadRight"));
  ui.stopPdf.addEventListener("click", () => send({ cmd: "stopBatch" }));
  byId("trainingReason").addEventListener("input", event => { if (!event.isComposing) saveCurrentReason(); });
  byId("trainingReason").addEventListener("compositionend", saveCurrentReason);

  ["prefixMode", "filenamePrefix", "filenameSuffix"].forEach((id) => {
    byId(id).addEventListener("input", () => {
      buildPreviewFilename();
      markSettingsDirty();
    });
    byId(id).addEventListener("change", () => {
      buildPreviewFilename();
      markSettingsDirty();
    });
  });
  ["firstWait", "nextWait"].forEach((id) => {
    byId(id).addEventListener("input", markSettingsDirty);
    byId(id).addEventListener("change", markSettingsDirty);
  });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "TOOLKIT_WORKFLOW_UPDATE") renderWorkflow(message.state);
  if (message?.type === "PROGRESS") refreshStates();
  if (message?.type === "DONE" || message?.type === "PAUSED") {
    copyTextToClipboard(message.text || "");
    refreshStates();
  }
  if (message?.type === "ERROR") refreshStates();
});

document.addEventListener("DOMContentLoaded", async () => {
  setExpandedPanel(null);
  bindActions();
  await refreshStates();
  try {
    await loadSettings();
    await refreshClassification();
    if (canClassify) byId("classificationStatus").textContent = "選擇分類即可保存此履歷的訓練標記。";
    if (canGroupJob) byId("jobGroupStatus").textContent = "同名群組已存在時直接加入，沒有時自動建立。";
  } catch (error) {
    byId("classificationStatus").textContent = `初始化失敗：${errorText(error)}`;
    byId("jobGroupStatus").textContent = `初始化失敗：${errorText(error)}`;
    updateClassificationAvailability();
  }
  setInterval(refreshStates, 900);
});
